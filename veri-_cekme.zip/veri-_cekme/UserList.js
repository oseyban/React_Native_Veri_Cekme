// UserList.js
import React, { useEffect, useState } from 'react';
import { View, ActivityIndicator, FlatList } from 'react-native';
import { User } from './User';
import { useRoute } from '@react-navigation/native';


export const UserList = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const route = useRoute(); 

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('https://dummyjson.com/users');
        const json = await response.json();
        console.log(json.users);
        setUsers(json.users);
        setLoading(false);
      } catch (error) {
        console.error('Veri çekme hatası:', error);
      }
    };

    fetchData();
  }, [route]);

  return (
    <View style={{width:"100%", height:"80%", alignItems:"center"}}>
      {loading ? (
        <ActivityIndicator size={"large"} color={ "#cD66FF"}/>)
       : (
        <FlatList
          data={users}
          keyExtractor={(item) => item.id.toString()}
          renderItem={({ item }) => <User data={item} />}
        />
      )}
    </View>
  );
};
