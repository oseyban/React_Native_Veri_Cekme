import { createStackNavigator } from '@react-navigation/stack';

import Profile from './screen/Profile';
import Home from './screen/Home';

const Stack = createStackNavigator();

export const Navigator=() => {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Home" component={Home} options={{title:"Anasayfa"}} />
      <Stack.Screen name="Profile" component={Profile} options={{title:"Profil Sayfası"}} /> 
    </Stack.Navigator> 
  );
}