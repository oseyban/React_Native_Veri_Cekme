// User.js
import React from 'react';
import { useNavigation } from '@react-navigation/native';
import { Image, View, StyleSheet, Text, TouchableOpacity } from 'react-native';

export const User = ({ data }) => {
  const nav = useNavigation();
  return (
    <TouchableOpacity
      onPress={() => {
        nav.navigate('Profile', { userID: data.id });
        alert(data.id);
      }}>
      <View style={styles.viewust}>
        <View style={{ ...styles.viewalt, flex: 2 }}>
          <Image style={styles.image} source={{ uri: data.image }} />
        </View>

        <View style={{ ...styles.viewalt, flex: 3 }}>
          {
            <Text style={styles.text}>
              {data.firstName} {data.lastName}
            </Text>
          }
          {<Text style={styles.textemail}>{data.email} </Text>}
        </View>

        <View style={{ ...styles.viewalt, flex: 1 }}>
          <View style={styles.daireview}>
            {<Text style={{ color: 'white' }}> {data.age} </Text>}
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  daireview: {
    width: 30,
    height: 30,
    borderRadius: 20,
    backgroundColor: '#BC85FF',
    justifyContent: 'center',
    alignItems: 'center',
  },
  text: {
    fontWeight: 'bold',
    fontSize: 20,
  },
  textemail: {
    fontSize: 15,
  },
  image: {
    width: 50,
    height: 50,
    borderRadius: 20,
    borderWidth: 2,
  },
  viewust: {
    padding: 8,
    width: '100%',
    height: 70,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    margin: 3,
  },
  viewalt: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 5,
  },
});
