import { View, StatusBar, SafeAreaView, StyleSheet } from 'react-native';
import { Navigator } from './Navigation';
import { NavigationContainer } from '@react-navigation/native';
import 'react-native-gesture-handler';
import { createStackNavigator } from '@react-navigation/stack';

export default function App() {
  return (
      <NavigationContainer>
        <View style={{backgroundColor: "white",flex:1}}>
        <StatusBar style="auto" />  
        <Navigator/>
        </View>
      </NavigationContainer>
    
  );
}


 
