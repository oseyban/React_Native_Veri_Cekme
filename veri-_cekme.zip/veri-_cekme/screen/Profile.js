import React, { useEffect, useState } from 'react';
import { Text, View, ActivityIndicator } from 'react-native';
import { useRoute } from '@react-navigation/native';

export const Profile = () => {
  const route = useRoute();
  const [user, setUser] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const userID = route.params.userID;
        const response = await fetch('https://dummyjson.com/users/' + userID);
        const json = await response.json();
        setUser(json);
      } catch (error) {
        console.error('Profil verisi çekme hatası:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [route.params.userID]);

  return (
    <View style={{ backgroundColor: 'white', flex: 1 }}>
      {loading ? (
        <Loading />
      ) : (
        <View>
          <Text>{user.name}</Text>
          {/* Diğer kullanıcı profil bilgilerini burada görüntüle */}
        </View>
      )}
    </View>
  );
};

const Loading = () => {
  return (
    <View
      style={{
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'white',
        flex: 1,
      }}>
      <ActivityIndicator size={'large'} color={'red'} />
    </View>
  );
};
